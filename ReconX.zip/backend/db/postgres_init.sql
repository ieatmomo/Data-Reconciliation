CREATE DATABASE reconcile;

-- -- If you want to create a schema inside the database:
-- CREATE SCHEMA IF NOT EXISTS reconcile;